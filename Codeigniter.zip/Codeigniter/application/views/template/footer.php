<footer>
	<div class="container">
		<hr>
		<p class="pull-right"><a href="#">Back to top</a></p>
		<p>&copy; Copyright 2022 <a href="#">Syahrul</a></p>
	</div>
</footer>