<div class="well well-lg">
	<div class="container">
		<h2>Kontak Kami</h2>
		<span>Beberapa kontak yang dapat dihubungi.</span>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-xs-3">
			<div class="list-group">
				<a href="<?php echo site_url("contact"); ?>" class="list-group-item">Kontak Kami</a>
				<a href="<?php echo site_url("tentang"); ?>" class="list-group-item">Tentang Website</a>
			</div>
		</div>
		<div class="col-xs-9">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 style="padding : 0; margin : 0;"> Tentang Website Pencari Kerja</h3>
				</div>
				<div class="panel-body">
					Terima kasih sudah mengunjungi website ini, apabila ada pertanyaan bisa hubungi beberapa kontak di bawah ini:
					<br>
					No HP : <b>08810273278900</b>
					<br>
					Email : <b>sahrul.tayadih@gmail.com</b>
				</div>
			</div>
		</div>
	</div>
</div>